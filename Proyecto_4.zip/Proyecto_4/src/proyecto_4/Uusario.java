package proyecto_4;

import java.util.Scanner;

public class Uusario {
    Scanner tc = new Scanner(System.in);
    //atributos
    private String nombre;
    private String apellido;
    private String direccion;
    
    //clase constructor
    public Uusario(){
    }

    public Uusario(String nombre, String apellido, String direccion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
    }

    //metodos set y gett
    public Scanner getTc() {
        return tc;
    }

    public void setTc(Scanner tc) {
        this.tc = tc;
    }

   

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
       public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    //metodos
    public void ingresardatos(){
        System.out.println("ingresa tu nombre");
        this.nombre= tc.nextLine();
        System.out.println("ingresa tu apellido");
        this.apellido= tc.nextLine() ;
        System.out.println("ingresa tu direccion");
        this.direccion= tc.nextLine() ;
    }
    
    public void mostrardatos(){
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.println("|su nombre es: " +nombre + "| |su apellido es: " +apellido+ "| |su direccion es: " +direccion+"|");
        System.out.println("---------------------------------------------------------------------------------------------");
    }
    
    
  
}
