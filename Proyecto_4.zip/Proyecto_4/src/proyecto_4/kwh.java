
package proyecto_4;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

public class kwh {
    //libreria Scanner
    Scanner tc = new Scanner(System.in);
    //atributos de la clase
    private Integer kwh;
    private Integer consumo=0;
    private Integer consumototal=0;
    
    private static HashMap<Integer, Integer>kwhlista;
    
    //metodo constructor
    public kwh() {
       
    }
    
    
    //metodos de la clase
    public void cantidadenergia(){
        System.out.println("ingresa la cantidad de khw a leer");
        kwh = tc.nextInt();
    }
    public void calcularenergia(){
        kwhlista = new HashMap<>();
        tc.nextLine();
        for (int i = 1; i <= kwh; i++) {
                //se pide el consumo 
            System.out.println("ingresa el consumo del kwh: "+(i)+", porfavor");
            consumo = tc.nextInt();
            
            
            kwhlista.put(i, consumo);
        }
    }
    public void calculartotaldekwh(){
    
        for (Integer total :kwhlista.values()) {   
            consumototal += total;
        }
    }
    public void mostrarconsumo(){
      for (Map.Entry<Integer, Integer> entry : kwhlista.entrySet()){
          Integer kilowatt = entry.getValue();
          System.out.println("khw: "+ kilowatt);
      }
          
  }
    public void mostrartotalconsumo(String nombre){
        System.out.println("-----------------------------------");    
        System.out.println(nombre+" el total de kwh es: "+consumototal);
        System.out.println("-----------------------------------");    
    }
    
    
}
