
package proyecto_4;
import java.util.HashMap;
import java.util.Map;
public class Proyecto_4 {
    
    public static void main(String[] args) {
        Uusario user = new Uusario();
        kwh eneregia = new kwh();
    
    user.ingresardatos();
    user.mostrardatos();
    
    eneregia.cantidadenergia();
    eneregia.calcularenergia();
    eneregia.mostrarconsumo();
    eneregia.calculartotaldekwh();
    eneregia.mostrartotalconsumo(user.getNombre()); 
    }
    
}
